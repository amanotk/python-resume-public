#!/usr/bin/env python
# -*- coding: utf-8 -*-

n = 10
x = 3.14


def main():
    print('main() is called')
    print('n = {}'.format(n))
    print('x = {}'.format(x))


if __name__ == '__main__':
    print('This will be printed only if run as a script')
    main()
