#!/usr/bin/env python
# -*- coding: utf-8 -*-

# 関数定義
def square(x):
    return x**2

x = 2.0
y = square(x) # 関数呼び出し

print('square of ', x, ' is ', y)
