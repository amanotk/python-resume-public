#!/usr/bin/env python
# -*- coding: utf-8 -*-

# キーボード入力を読み込む
s = input('Input something: ')
print('Your input is : ', s)

# 整数に変換
a = int(input('Input integer 1: '))
b = int(input('Input integer 2: '))
print('Sum of two integers : ', a + b)

# 実数に変換
c = float(input('Input real: '))
print('Square of float : ', c*c)
