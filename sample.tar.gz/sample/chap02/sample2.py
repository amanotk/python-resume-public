#!/usr/bin/env python
# -*- coding: utf-8 -*-

n = 10           # nは整数 (4byte = 32bit)
x = 3.14         # xは実数 (8byte = 64bit)

print('n = ', n)
print('x = ', x)

# 以下はエラー
#print('y = ', y)
